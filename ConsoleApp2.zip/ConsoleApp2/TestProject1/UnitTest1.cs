namespace TestProject1
{
    using static ConsoleApp2.Class1;

    [TestClass]
    public class CalculadoraTeste
    {
        private Calculadora _calculadora;

        [TestInitialize]
        public void Setup()
        {
            _calculadora = new Calculadora();
        }

        [TestMethod]
        public void TestarSoma()
        {
            double resultado = _calculadora.Somar(10, 5);
            Assert.AreEqual(15, resultado, 0.001, "A soma n�o est� correta");
        }

        [TestMethod]
        public void TestarSubtracao()
        {
            double resultado = _calculadora.Subtrair(10, 5);
            Assert.AreEqual(5, resultado, 0.001, "A subtra��o n�o est� correta");
        }

        [TestMethod]
        public void TestarMultiplicacao()
        {
            double resultado = _calculadora.Multiplicar(10, 5);
            Assert.AreEqual(50, resultado, 0.001, "A multiplica��o n�o est� correta");
        }

        [TestMethod]
        public void TestarDivisao()
        {
            double resultado = _calculadora.Dividir(10, 5);
            Assert.AreEqual(2, resultado, 0.001, "A divis�o n�o est� correta");
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void TestarDivisaoPorZero()
        {
            _calculadora.Dividir(10, 0);
        }
    }

}