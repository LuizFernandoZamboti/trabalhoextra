﻿using static ConsoleApp2.Class1;
using System;

class Program
{
    static void Main(string[] args)
    {
        Calculadora calculadora = new Calculadora();
        int opcao;
        double num1, num2;

        while (true)
        {
            Console.WriteLine("Escolha a operação: \n1. Soma \n2. Subtração \n3. Multiplicação \n4. Divisão \n5. Sair");
            try
            {
                opcao = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Por favor, insira um número válido para a opção.");
                continue;
            }

            if (opcao == 5)
            {
                break;
            }

            try
            {
                Console.Write("Digite o primeiro número: ");
                num1 = Convert.ToDouble(Console.ReadLine());

                Console.Write("Digite o segundo número: ");
                num2 = Convert.ToDouble(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Por favor, insira um número válido.");
                continue;
            }

            switch (opcao)
            {
                case 1:
                    Console.WriteLine($"Resultado: {calculadora.Somar(num1, num2)}");
                    break;
                case 2:
                    Console.WriteLine($"Resultado: {calculadora.Subtrair(num1, num2)}");
                    break;
                case 3:
                    Console.WriteLine($"Resultado: {calculadora.Multiplicar(num1, num2)}");
                    break;
                case 4:
                    try
                    {
                        Console.WriteLine($"Resultado: {calculadora.Dividir(num1, num2)}");
                    }
                    catch (DivideByZeroException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }
        }
    }
}
