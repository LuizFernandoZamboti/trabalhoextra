using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TestProject1
{
    [TestClass]
    public class CalculadoraTests
    {
        [TestMethod]
        public void TestarSoma()
        {
            var soma = new Soma();
            var resultado = soma.Calcular(5, 3);
            Assert.AreEqual(8, resultado);
        }

        [TestMethod]
        public void TestarSubtracao()
        {
            var subtracao = new Subtracao();
            var resultado = subtracao.Calcular(5, 3);
            Assert.AreEqual(2, resultado);
        }

        [TestMethod]
        public void TestarMultiplicacao()
        {
            var multiplicacao = new Multiplicacao();
            var resultado = multiplicacao.Calcular(5, 3);
            Assert.AreEqual(15, resultado);
        }

        [TestMethod]
        public void TestarDivisao()
        {
            var divisao = new Divisao();
            var resultado = divisao.Calcular(6, 3);
            Assert.AreEqual(2, resultado);
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void TestarDivisaoPorZero()
        {
            var divisao = new Divisao();
            var resultado = divisao.Calcular(5, 0);
        }
    }
}