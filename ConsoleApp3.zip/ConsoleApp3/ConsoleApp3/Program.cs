﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int opcao;
        double num1, num2;

        while (true)
        {
            Console.WriteLine("Escolha a operação: \n1. Soma \n2. Subtração \n3. Multiplicação \n4. Divisão \n5. Sair");
            try
            {
                opcao = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Por favor, insira um número válido para a opção.");
                continue;
            }

            if (opcao == 5)
            {
                break;
            }

            try
            {
                Console.Write("Digite o primeiro número: ");
                num1 = Convert.ToDouble(Console.ReadLine());

                Console.Write("Digite o segundo número: ");
                num2 = Convert.ToDouble(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Por favor, insira um número válido.");
                continue;
            }

            switch (opcao)
            {
                case 1:
                    Soma soma = new Soma();
                    Console.WriteLine($"Resultado: {soma.Calcular(num1, num2)}");
                    break;
                case 2:
                    Subtracao subtracao = new Subtracao();
                    Console.WriteLine($"Resultado: {subtracao.Calcular(num1, num2)}");
                    break;
                case 3:
                    Multiplicacao multiplicacao = new Multiplicacao();
                    Console.WriteLine($"Resultado: {multiplicacao.Calcular(num1, num2)}");
                    break;
                case 4:
                    Divisao divisao = new Divisao();
                    try
                    {
                        Console.WriteLine($"Resultado: {divisao.Calcular(num1, num2)}");
                    }
                    catch (DivideByZeroException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }
        }
    }
}